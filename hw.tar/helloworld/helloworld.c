int main(int argc,char** argv)
{
	printf("hello,linux world");
	return 0;
}
