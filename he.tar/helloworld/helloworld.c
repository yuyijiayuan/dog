#include<stdio.h>

int main(int argc,char **argv)
{
	printf("新年快乐！");
	return 0;
}
